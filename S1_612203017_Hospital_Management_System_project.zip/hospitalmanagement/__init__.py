# __init__.py

default_app_config = 'hospital.apps.HospitalConfig'
